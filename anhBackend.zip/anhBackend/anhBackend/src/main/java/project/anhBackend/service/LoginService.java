package project.anhBackend.service;

import project.anhBackend.dto.UserDto;
import project.anhBackend.loginRequest.LoginRequest;

public interface LoginService {

    UserDto getUser(String username,String password);
}
