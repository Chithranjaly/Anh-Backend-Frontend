package project.anhBackend.service;

import project.anhBackend.dto.GetInstructorDto;
import project.anhBackend.dto.InstructorDto;

import java.util.List;

public interface InstructorService {

    InstructorDto addInstructor(InstructorDto instructorDto);
    InstructorDto getInstructorById(Long instructorId);
    List<InstructorDto> getAllInstructors();
    InstructorDto updateInstructor(Long instructorId,InstructorDto instructorDto);
    void deleteInstructor(Long instructorId);
    List<GetInstructorDto> getAll();

}
