package project.anhBackend.service.serviceImpl;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import project.anhBackend.dto.DepartmentDto;
import project.anhBackend.entity.Department;
import project.anhBackend.exception.ResourceNotFoundException;
import project.anhBackend.repository.DepartmentRepo;
import project.anhBackend.service.DepartmentService;
import org.modelmapper.ModelMapper;

import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class DepartmentServiceImpl implements DepartmentService {


    private DepartmentRepo departmentRepo;
    private ModelMapper modelMapper;

    @Override
    public DepartmentDto createDepartment(DepartmentDto departmentDto) {
        Department department=modelMapper.map(departmentDto,Department.class);
        Department savedDepartment=departmentRepo.save(department);
        return modelMapper.map(savedDepartment,DepartmentDto.class);
    }

    @Override
    public DepartmentDto getDepartmentById(Long departmentId) {
        Department department=departmentRepo.findById(departmentId).orElseThrow(
                ()-> new ResourceNotFoundException("Department not exist with id"+ departmentId)
        );
        return modelMapper.map(department,DepartmentDto.class);
    }

    @Override
    public List<DepartmentDto> getAllDepartments() {
        List<Department> departments=departmentRepo.findAll();
        return departments.stream().map((department)->
                modelMapper.map(department,DepartmentDto.class)).collect(Collectors.toList());
    }

    @Override
    public DepartmentDto updateDepartment(Long departmentId, DepartmentDto updatedDepartment) {
        Department department=departmentRepo.findById(departmentId).orElseThrow(
                ()-> new ResourceNotFoundException("Department not exist with id"+ departmentId)
        );
        department.setDep_name(updatedDepartment.getDep_name());
        department.setDep_description(updatedDepartment.getDep_description());
        Department savedDepartment=departmentRepo.save(department);
        return modelMapper.map(savedDepartment,DepartmentDto.class);
    }

    @Override
    public void deleteDepartment(Long departmentId) {
        Department department=departmentRepo.findById(departmentId).orElseThrow(
                ()-> new ResourceNotFoundException("Department not exist with id"+ departmentId)
        );
        departmentRepo.deleteById(departmentId);

    }
}
