package project.anhBackend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import project.anhBackend.entity.Student;

public interface StudentRepo extends JpaRepository<Student, Long> {

    Student findByUsername(String username);
}
