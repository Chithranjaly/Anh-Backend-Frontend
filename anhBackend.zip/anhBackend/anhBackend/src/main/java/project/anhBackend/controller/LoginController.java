package project.anhBackend.controller;

import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import project.anhBackend.dto.UserDto;
import project.anhBackend.loginRequest.LoginRequest;
import project.anhBackend.service.LoginService;

@RestController
@CrossOrigin("*")
@AllArgsConstructor
@RequestMapping("/api/login")
public class LoginController {

    private LoginService loginService;


    @PostMapping()
    public ResponseEntity<UserDto> getUser(@RequestBody LoginRequest loginRequest){
        String username=loginRequest.getUsername();
        String password=loginRequest.getPassword();
        UserDto userDto=loginService.getUser(username,password);
        if(userDto !=null){
            return new ResponseEntity<>(userDto, HttpStatus.OK);
        }
        else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

    }
}
