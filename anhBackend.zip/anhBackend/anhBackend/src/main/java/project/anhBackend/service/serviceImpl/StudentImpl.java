package project.anhBackend.service.serviceImpl;

import lombok.AllArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import project.anhBackend.dto.DepartmentDto;
import project.anhBackend.dto.StudentDto;
import project.anhBackend.entity.Department;
import project.anhBackend.entity.Student;
import project.anhBackend.entity.User;
import project.anhBackend.exception.ResourceNotFoundException;
import project.anhBackend.repository.StudentRepo;
import project.anhBackend.repository.UserRepo;
import project.anhBackend.service.StudentService;

import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class StudentImpl implements StudentService {

    private ModelMapper modelMapper;
    private StudentRepo studentRepo;
    private UserRepo userRepo;

    @Override
    public StudentDto RegisterStudent(StudentDto studentDto) {
        Student stu=modelMapper.map(studentDto,Student.class);
        Student savedStudent=studentRepo.save(stu);

        User user=new User();
        user.setUser_id(stu.getId());
        user.setUsername(stu.getUsername());
        user.setPassword(stu.getPassword());
        user.setRole("STUDENT");

        userRepo.save(user);

        return modelMapper.map(savedStudent,StudentDto.class);




    }

    @Override
    public StudentDto getStudentById(Long studentId) {
        Student student=studentRepo.findById(studentId).orElseThrow(
                ()-> new ResourceNotFoundException("Department not exist with id"+ studentId)
        );
        return modelMapper.map(student, StudentDto.class);

    }

    @Override
    public List<StudentDto> getAllStudents() {
        List<Student> students=studentRepo.findAll();
        return students.stream().map((student)->
                modelMapper.map(student,StudentDto.class)).collect(Collectors.toList());
    }

    @Override
    public StudentDto updateStudent(Long studentId, StudentDto updatedStudent) {
        Student student=studentRepo.findById(studentId).orElseThrow(
                ()-> new ResourceNotFoundException("Department not exist with id"+ studentId)
        );
        student.setF_name(updatedStudent.getF_name());
        student.setL_name(updatedStudent.getL_name());
        student.setAge(updatedStudent.getAge());
        student.setPhone(updatedStudent.getPhone());

        User user=userRepo.findByUsername(student.getUsername());
        user.setUsername(updatedStudent.getUsername());
        user.setPassword(updatedStudent.getPassword());
        user.setRole("STUDENT");
        userRepo.save(user);


        student.setUsername(updatedStudent.getUsername());
        student.setPassword(updatedStudent.getPassword());
        Student savedStudent=studentRepo.save(student);



        return modelMapper.map(savedStudent,StudentDto.class);

    }

    @Override
    public void deleteStudent(Long studentId) {
        Student student=studentRepo.findById(studentId).orElseThrow(
                ()-> new ResourceNotFoundException("Student not exist with id"+ studentId)
        );
        User user=userRepo.findByUsername(student.getUsername());
        Long userId=user.getId();
        userRepo.deleteById(userId);
        studentRepo.deleteById(studentId);

    }
}
