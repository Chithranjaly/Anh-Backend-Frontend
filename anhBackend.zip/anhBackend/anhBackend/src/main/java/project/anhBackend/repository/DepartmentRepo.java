package project.anhBackend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import project.anhBackend.entity.Department;

public interface DepartmentRepo extends JpaRepository<Department, Long> {
}
