package project.anhBackend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import project.anhBackend.dto.GetInstructorDto;
import project.anhBackend.dto.InstructorDto;
import project.anhBackend.entity.Instructor;

import java.util.List;

public interface InstructorRepo extends JpaRepository<Instructor,Long> {
    Instructor findByUsername(String username);

    @Query("SELECT new project.anhBackend.dto.GetInstructorDto(i.id, i.f_name, i.l_name, i.email, i.phone, d.dep_name) FROM Instructor i LEFT JOIN i.department d")
    public List<GetInstructorDto> getAllDetails();
}
