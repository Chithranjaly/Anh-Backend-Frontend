package project.anhBackend.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class GetInstructorDto {
    private Long id;
    private String f_name;
    private String l_name;
    private String email;
    private String phone;
    private String dep_name;
}
