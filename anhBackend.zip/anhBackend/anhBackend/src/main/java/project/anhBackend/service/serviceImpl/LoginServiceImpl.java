package project.anhBackend.service.serviceImpl;

import lombok.AllArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import project.anhBackend.dto.UserDto;
import project.anhBackend.entity.User;
import project.anhBackend.exception.ResourceNotFoundException;
import project.anhBackend.loginRequest.LoginRequest;
import project.anhBackend.repository.UserRepo;
import project.anhBackend.service.LoginService;

@Service
@AllArgsConstructor
public class LoginServiceImpl implements LoginService {

    private UserRepo userRepo;
    private ModelMapper modelMapper;

    @Override
    public UserDto getUser(String username,String password) {
        User user=userRepo.findByUsername(username);
        if (user!=null){
            if((user.getUsername().equals(username))&&(user.getPassword().equals(password)))
            {
                return modelMapper.map(user,UserDto.class);
            }else {
                return null;
            }
        }
        return null;
    }
}
